# IOS-Dev-Project
Harding

Developers:  Nathan Daughety, Cade Jenkins, Jake Black

Description:
  This app contains a level tool and an RGB interpretor.  The level
is similar to the bubble level you would find in your tool box.  The
RGB interpretor is a feature that allows the user to select an image
from their device's storage and interpret the RGB value of an individual
pixel in the image by using a long-press gesture.
